# Обучение двуязычной (ru+en) модели с упором на код

Этот гайд — для обучения **~350M модели** на русском + английском + коде за **~5-6 часов на одной A100/H100**. Дополняет основной README (там — устройство модели и механизм ревизии).

> Честная планка: ~350M даёт беглый двуязычный текст, хорошее «чувство» кода (синтаксис, идиомы, дополнение), но лишь **поверхностные** знания предметов. Реальное знание физики/биологии требует 7B+. Фокус — код, он достижим на этом размере.

## Стратегия в два этапа (не жги деньги на отладке)

**Фаза 1 — на дешёвой машине (3090 / $0.3/час):** отладить весь пайплайн на маленьком сэмпле. Часы и копейки.

**Фаза 2 — аренда A100 80GB:** только когда Фаза 1 чистая — полный корпус и обучение. Тут считается каждый час.

---

## Фаза 1: отладка на малом сэмпле

```bash
pip install -e .

# 1. Скачать маленький мультидоменный сэмпл (ru+en+код+наука)
python -m scripts.download_corpus --preset small
# -> data/raw/{ru_wiki,en_wiki,ru_web,en_web,code,science}.jsonl

# 2. Обработать код (фильтр качества + докстринг-пары + FIM)
python -m src.data.build_code_data \
    --input data/raw/code.jsonl \
    --out data/raw/code_processed.jsonl
# затем удали сырой code.jsonl, чтобы не дублировать:
rm data/raw/code.jsonl

# 3. Двуязычный токенизатор (vocab 48k — вместит кириллицу + код)
#    объединяем все домены для обучения BPE
cat data/raw/*.jsonl | python -c "import sys,json; [print(json.loads(l)['text']) for l in sys.stdin]" > data/raw/_tok_corpus.txt
python -m src.tokenizer.train_tokenizer \
    --input data/raw/_tok_corpus.txt \
    --out tokenizer.json --vocab_size 48000
#    запомни реальный vocab_size из вывода и впиши в configs/model_mid.yaml

# 4. Подготовка данных (ПАРАЛЛЕЛЬНЫЙ дедуп + батч-токенизация)
python -m src.data.prepare_pretrain \
    --input data/raw \
    --tokenizer tokenizer.json \
    --out_dir data/processed \
    --workers 0          # 0 = все ядра

# 5. Короткий тест обучения (урезанный конфиг — проверить, что lm падает)
sed -i 's/max_steps: 12000/max_steps: 300/' configs/train_mid.yaml
python -m src.train.train_pretrain \
    --model_config configs/model_mid.yaml \
    --train_config configs/train_mid.yaml
```

Если `lm` падает и нет ошибок — Фаза 1 пройдена. Верни `max_steps` обратно.

---

## Фаза 2: полный прогон на A100/H100

```bash
# 1. Полный корпус (~5-6 млрд токенов). Долго качается — запускай заранее.
python -m scripts.download_corpus --preset poc
python -m src.data.build_code_data --input data/raw/code.jsonl --out data/raw/code_processed.jsonl
rm data/raw/code.jsonl

# 2. Токенизатор и подготовка — как в Фазе 1, шаги 3-4
#    (на большом корпусе дедуп идёт на всех ядрах, токенизация батчами)

# 3. Этап A — претрейн базы (~5-6 ч)
sed -i 's/max_steps: 300/max_steps: 12000/' configs/train_mid.yaml   # если правил
python -m src.train.train_pretrain \
    --model_config configs/model_mid.yaml \
    --train_config configs/train_mid.yaml

# 4. Этап B — обучение ревизии (поверх базы)
python -m src.data.build_revision_data \
    --mode synthetic_corrupt \
    --input data/raw/_tok_corpus.txt \
    --tokenizer tokenizer.json \
    --out data/revision_traces/traces.jsonl

python -m src.train.train_revision \
    --model_config configs/model_mid.yaml \
    --train_config configs/train_mid.yaml \
    --init checkpoints/final_12000.pt

# 5. Генерация (ru, en, код) с откатами
python -m src.inference.generate \
    --ckpt checkpoints/final_12000.pt \
    --model_config configs/model_mid.yaml \
    --tokenizer tokenizer.json \
    --prompt "def quicksort(arr):" --verbose --device cuda

# 6. Замер ревизия vs бейзлайн
python -m src.eval.eval_revision \
    --ckpt checkpoints/final_12000.pt \
    --model_config configs/model_mid.yaml \
    --tokenizer tokenizer.json \
    --prompts data/eval_prompts.txt --device cuda
```

---

## Источники данных (все публичные)

| Домен | Датасет | Назначение |
|---|---|---|
| `ru_wiki` | Wikipedia ru | русский язык + база знаний |
| `en_wiki` | Wikipedia en | английский + знания |
| `ru_web` | CulturaX (ru) | беглость русского |
| `en_web` | FineWeb-Edu | качественный английский |
| `code` | the-stack-smol | код (Python/JS/C++/Rust/Go/Java) |
| `science` | OpenWebMath | математика/рассуждения |

**Замена кода на больший объём:** the-stack-smol удобен (без gating). Для серьёзного объёма — `bigcode/the-stack-v2` (нужен HF-токен + принять лицензию на сайте, затем `huggingface-cli login`). Поправь `dl_code` в `scripts/download_corpus.py`.

## Обработка кода — что делает build_code_data

Три вещи, повышающие «ожидаемость» генерируемого кода:
1. **Фильтр качества** — выкидывает минифицированное, автоген, файлы с малой долей кода.
2. **Докстринг-пары** (Python, через AST) — «сигнатура+докстринг → тело». Учит отвечать кодом на описание.
3. **FIM** (fill-in-the-middle) — учит дополнять код в середине. Спецтокены `<FIM_PRE>`, `<FIM_SUF>`, `<FIM_MID>`.

## Память и масштаб

- `model_mid` (~350M) с `grad_checkpoint: true` влезает в A100 80GB с батчем 24.
- Если OOM: уменьши `batch_size`, увеличь `grad_accum_steps` (эффективный батч тот же).
- `compile: true` ускоряет крупную модель — оставь для длинного прогона (первый шаг медленный).
- Все баги из ранней разработки уже исправлены в коде (MoE dtype под bf16, GradScaler API, откат по confidence, параллельный дедуп).

## Подбор объёма под время

Лимиты в `scripts/download_corpus.py` (`PRESETS`) заданы в **документах**. Грубо 1 док ≈ 300-800 токенов. Если прогон не укладывается в 5-6 ч — уменьши `max_steps` или лимиты пресета `poc`. Лучше недообучить и успеть весь цикл (A→B→eval), чем застрять на этапе A.
