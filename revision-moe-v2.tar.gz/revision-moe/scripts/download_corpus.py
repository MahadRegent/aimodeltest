"""Загрузка публичных датасетов в data/raw/ как .jsonl с полем "text".

Все источники — открытые, без gating (кроме помеченных). Каждый домен пишется
в отдельный файл, чтобы можно было смешивать в нужных долях через --weights
в prepare_pretrain (или просто скормить всю папку data/raw).

Использование (примеры):
  # быстрый тест (мало данных, для отладки на дешёвой машине):
  python -m scripts.download_corpus --preset small

  # целевой корпус ~5-6 млрд токенов под обучение за 5-6 часов:
  python -m scripts.download_corpus --preset poc

  # отдельные домены:
  python -m scripts.download_corpus --domains ru_wiki code en_web

ВАЖНО про лимиты: размеры заданы в документах (--limit-ы), не в токенах.
Грубо 1 документ ~ 300-800 токенов. Подбери под бюджет.
"""
import argparse
import json
import os

OUT_DIR = "data/raw"


def _writer(path):
    f = open(path, "w", encoding="utf-8")
    def write(text):
        text = (text or "").replace("\n", " ").strip()
        if len(text) > 50:
            f.write(json.dumps({"text": text}, ensure_ascii=False) + "\n")
    return f, write


def dl_ru_wiki(limit):
    """Русская Википедия — основа русского языка и базовых знаний по предметам."""
    from datasets import load_dataset
    ds = load_dataset("wikimedia/wikipedia", "20231101.ru", split="train", streaming=True)
    f, w = _writer(f"{OUT_DIR}/ru_wiki.jsonl")
    for i, ex in enumerate(ds):
        if i >= limit:
            break
        w(ex["text"])
    f.close()
    print(f"ru_wiki: ~{min(i+1, limit)} статей")


def dl_en_wiki(limit):
    """Английская Википедия."""
    from datasets import load_dataset
    ds = load_dataset("wikimedia/wikipedia", "20231101.en", split="train", streaming=True)
    f, w = _writer(f"{OUT_DIR}/en_wiki.jsonl")
    for i, ex in enumerate(ds):
        if i >= limit:
            break
        w(ex["text"])
    f.close()
    print(f"en_wiki: ~{min(i+1, limit)} статей")


def dl_ru_web(limit):
    """Русский веб — CulturaX (большой чистый мультиязычный корпус)."""
    from datasets import load_dataset
    # CulturaX gated? нет, но крупный. Берём русскую часть стримом.
    ds = load_dataset("uonlp/CulturaX", "ru", split="train", streaming=True)
    f, w = _writer(f"{OUT_DIR}/ru_web.jsonl")
    for i, ex in enumerate(ds):
        if i >= limit:
            break
        w(ex["text"])
    f.close()
    print(f"ru_web (CulturaX): ~{min(i+1, limit)} документов")


def dl_en_web(limit):
    """Английский веб — FineWeb-Edu (качественный образовательный)."""
    from datasets import load_dataset
    ds = load_dataset("HuggingFaceFW/fineweb-edu", "sample-10BT",
                      split="train", streaming=True)
    f, w = _writer(f"{OUT_DIR}/en_web.jsonl")
    for i, ex in enumerate(ds):
        if i >= limit:
            break
        w(ex["text"])
    f.close()
    print(f"en_web (FineWeb-Edu): ~{min(i+1, limit)} документов")


def dl_code(limit):
    """Код — the-stack-smol (без gating, удобно для старта).
    Для серьёзного объёма заменить на bigcode/the-stack-v2 (нужен HF-токен)."""
    from datasets import load_dataset
    # the-stack-smol: подвыборка по языкам, без gating
    langs = ["python", "javascript", "c++", "rust", "go", "java"]
    f, w = _writer(f"{OUT_DIR}/code.jsonl")
    per_lang = max(1, limit // len(langs))
    total = 0
    for lang in langs:
        try:
            ds = load_dataset("bigcode/the-stack-smol", data_dir=f"data/{lang}",
                              split="train", streaming=True)
            for i, ex in enumerate(ds):
                if i >= per_lang:
                    break
                w(ex.get("content", ""))
                total += 1
        except Exception as e:
            print(f"  [warn] {lang}: {e}")
    f.close()
    print(f"code: ~{total} файлов ({', '.join(langs)})")


def dl_science(limit):
    """Наука/математика — OpenWebMath (математические тексты, языко-нейтральны)."""
    from datasets import load_dataset
    ds = load_dataset("open-web-math/open-web-math", split="train", streaming=True)
    f, w = _writer(f"{OUT_DIR}/science.jsonl")
    for i, ex in enumerate(ds):
        if i >= limit:
            break
        w(ex["text"])
    f.close()
    print(f"science (OpenWebMath): ~{min(i+1, limit)} документов")


DOMAINS = {
    "ru_wiki": dl_ru_wiki,
    "en_wiki": dl_en_wiki,
    "ru_web": dl_ru_web,
    "en_web": dl_en_web,
    "code": dl_code,
    "science": dl_science,
}

# пресеты: лимиты в документах на домен
PRESETS = {
    # быстрый тест на дешёвой машине — проверить ru+en+код+кириллицу
    "small": {"ru_wiki": 20000, "en_wiki": 10000, "ru_web": 20000,
              "en_web": 20000, "code": 20000, "science": 5000},
    # целевой PoC ~5-6 млрд токенов (упор на код)
    "poc": {"code": 3000000, "ru_wiki": 1500000, "ru_web": 2000000,
            "en_web": 1500000, "en_wiki": 800000, "science": 500000},
}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--preset", choices=list(PRESETS), default=None)
    ap.add_argument("--domains", nargs="+", choices=list(DOMAINS), default=None)
    ap.add_argument("--limit", type=int, default=50000,
                    help="лимит документов на домен (если не пресет)")
    args = ap.parse_args()

    os.makedirs(OUT_DIR, exist_ok=True)

    if args.preset:
        limits = PRESETS[args.preset]
        for dom, lim in limits.items():
            print(f"=== {dom} (limit {lim}) ===")
            try:
                DOMAINS[dom](lim)
            except Exception as e:
                print(f"  [error] {dom}: {e}\n  (пропускаю — проверь доступ/токен HF)")
    else:
        doms = args.domains or ["ru_wiki", "en_web", "code"]
        for dom in doms:
            print(f"=== {dom} (limit {args.limit}) ===")
            try:
                DOMAINS[dom](args.limit)
            except Exception as e:
                print(f"  [error] {dom}: {e}")

    print(f"\nГотово. Файлы в {OUT_DIR}/ — дальше токенизатор и prepare_pretrain.")


if __name__ == "__main__":
    main()
