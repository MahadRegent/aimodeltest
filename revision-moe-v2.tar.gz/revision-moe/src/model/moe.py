"""MoE FFN-слой. Ключевая фишка проекта: возвращает дисперсию между выбранными
экспертами как сигнал неопределённости для головы уверенности, плюс
load-balancing (aux) loss для равномерной загрузки экспертов."""
import torch
import torch.nn as nn
import torch.nn.functional as F


class Expert(nn.Module):
    """Один эксперт = SwiGLU FFN."""
    def __init__(self, dim, hidden):
        super().__init__()
        self.w1 = nn.Linear(dim, hidden, bias=False)
        self.w2 = nn.Linear(hidden, dim, bias=False)
        self.w3 = nn.Linear(dim, hidden, bias=False)

    def forward(self, x):
        return self.w2(F.silu(self.w1(x)) * self.w3(x))


class MoE(nn.Module):
    def __init__(self, dim, hidden, n_experts, top_k):
        super().__init__()
        self.n_experts = n_experts
        self.top_k = top_k
        self.dim = dim
        self.router = nn.Linear(dim, n_experts, bias=False)
        self.experts = nn.ModuleList([Expert(dim, hidden) for _ in range(n_experts)])

    def forward(self, x):
        """
        x: [B, T, dim]
        Возвращает:
          out:          [B, T, dim]   взвешенный выход top-k экспертов
          aux_loss:     scalar        load-balancing loss
          expert_var:   [B, T]        дисперсия между выбранными экспертами (uncertainty)
        """
        B, T, D = x.shape
        x_flat = x.reshape(-1, D)                      # [N, D], N = B*T
        N = x_flat.shape[0]
        # dtype, согласованный с autocast (bf16/fp16): берём по выходу эксперта
        compute_dtype = self.experts[0](x_flat[:1]).dtype

        logits = self.router(x_flat)                   # [N, E]
        probs = F.softmax(logits, dim=-1)              # [N, E]

        topk_probs, topk_idx = probs.topk(self.top_k, dim=-1)   # [N, k]
        topk_probs = topk_probs / (topk_probs.sum(dim=-1, keepdim=True) + 1e-9)

        # считаем выход каждого выбранного эксперта (и сохраняем для дисперсии)
        out = torch.zeros(N, D, device=x.device, dtype=compute_dtype)
        # стек выходов выбранных экспертов: [N, k, D]
        chosen_outputs = torch.zeros(N, self.top_k, D, device=x.device, dtype=compute_dtype)

        for slot in range(self.top_k):
            idx = topk_idx[:, slot]                    # [N] какой эксперт в этом слоте
            w = topk_probs[:, slot].unsqueeze(-1)      # [N, 1] его вес
            # обрабатываем токены сгруппированно по экспертам
            for e in range(self.n_experts):
                mask = idx == e
                if mask.any():
                    y = self.experts[e](x_flat[mask])  # [n_e, D]
                    chosen_outputs[mask, slot] = y
                    out[mask] += w[mask] * y

        # дисперсия между выбранными экспертами как сигнал неопределённости.
        # высокая дисперсия = эксперты "не согласны" = модель неуверена.
        expert_var = chosen_outputs.var(dim=1).mean(dim=-1)   # [N]

        # load-balancing loss (Switch Transformer): минимизируем произведение
        # доли токенов на эксперта и средней вероятности роутера на эксперта.
        with torch.no_grad():
            one_hot = F.one_hot(topk_idx[:, 0], self.n_experts).float()  # по top-1
            tokens_per_expert = one_hot.mean(dim=0)        # [E]
        router_prob_per_expert = probs.mean(dim=0)         # [E]
        aux_loss = self.n_experts * (tokens_per_expert * router_prob_per_expert).sum()

        return out.view(B, T, D), aux_loss, expert_var.view(B, T)
