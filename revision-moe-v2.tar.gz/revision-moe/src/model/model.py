"""Сборка Revision-MoE модели целиком."""
import torch
import torch.nn as nn
import torch.nn.functional as F

from .attention import precompute_rope
from .block import Block, RMSNorm
from .confidence_head import ConfidenceHead


class RevisionMoE(nn.Module):
    def __init__(self, cfg: dict):
        super().__init__()
        self.cfg = cfg
        dim = cfg["dim"]
        self.max_seq_len = cfg["max_seq_len"]

        self.tok_emb = nn.Embedding(cfg["vocab_size"], dim)
        moe_layers = set(cfg.get("moe_layers", []))
        self.layers = nn.ModuleList([
            Block(cfg, is_moe=(i in moe_layers)) for i in range(cfg["n_layers"])
        ])
        self.norm = RMSNorm(dim, cfg["norm_eps"])
        self.lm_head = nn.Linear(dim, cfg["vocab_size"], bias=False)
        self.tok_emb.weight = self.lm_head.weight  # weight tying

        self.use_confidence = cfg.get("use_confidence_head", False)
        if self.use_confidence:
            self.confidence_head = ConfidenceHead(dim, cfg["confidence_hidden"])

        self.grad_checkpoint = cfg.get("grad_checkpoint", False)

        head_dim = dim // cfg["n_heads"]
        cos, sin = precompute_rope(head_dim, cfg["max_seq_len"], cfg["rope_theta"])
        self.register_buffer("rope_cos", cos, persistent=False)
        self.register_buffer("rope_sin", sin, persistent=False)

        self.apply(self._init_weights)

    def _init_weights(self, m):
        if isinstance(m, nn.Linear):
            nn.init.normal_(m.weight, mean=0.0, std=0.02)
        elif isinstance(m, nn.Embedding):
            nn.init.normal_(m.weight, mean=0.0, std=0.02)

    def forward(self, idx, kv_caches=None, pos_offset=0, return_confidence=False):
        """
        idx: [B, T] token ids
        kv_caches: список dict-ов по слоям (для инференса) либо None (обучение).
        Возвращает dict: logits, aux_loss, expert_var, confidence_logit, new_kv_caches
        """
        B, T = idx.shape
        x = self.tok_emb(idx)
        cos, sin = self.rope_cos, self.rope_sin

        new_caches = []
        total_aux = 0.0
        n_moe = 0
        last_expert_var = torch.zeros(B, T, device=idx.device, dtype=x.dtype)

        for i, layer in enumerate(self.layers):
            cache = kv_caches[i] if kv_caches is not None else None
            if self.grad_checkpoint and self.training and kv_caches is None:
                # пересчёт активаций вместо хранения — экономит память на больших моделях
                x, new_cache, aux, evar = torch.utils.checkpoint.checkpoint(
                    layer, x, cos, sin, cache, pos_offset, use_reentrant=False)
            else:
                x, new_cache, aux, evar = layer(x, cos, sin, cache, pos_offset)
            new_caches.append(new_cache)
            if aux is not None:
                total_aux = total_aux + aux
                n_moe += 1
                last_expert_var = evar  # берём дисперсию с последнего MoE-слоя

        x = self.norm(x)
        logits = self.lm_head(x)
        aux_loss = total_aux / max(n_moe, 1)

        out = {
            "logits": logits,
            "aux_loss": aux_loss,
            "expert_var": last_expert_var,
            "new_kv_caches": new_caches,
            "confidence_logit": None,
        }
        if self.use_confidence and return_confidence:
            out["confidence_logit"] = self.confidence_head(x, logits, last_expert_var)
        return out

    def num_params(self):
        return sum(p.numel() for p in self.parameters())
