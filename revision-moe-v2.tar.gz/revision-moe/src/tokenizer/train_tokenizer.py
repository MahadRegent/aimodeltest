"""Обучение BPE-токенизатора со спецтокенами ревизии.

Использование:
  python -m src.tokenizer.train_tokenizer \
      --input data/raw/corpus.txt \
      --out tokenizer.json --vocab_size 32000

Вход: один или несколько .txt файлов (по строке-документу или просто текст).
Выход: tokenizer.json — его путь потом указывается при подготовке данных.
"""
import argparse
from tokenizers import Tokenizer, models, trainers, pre_tokenizers, decoders

from src.model.revision import SPECIAL_TOKENS

# FIM-токены для обучения дополнению кода в середине
FIM_TOKENS = ["<FIM_PRE>", "<FIM_SUF>", "<FIM_MID>"]

# базовые спец-токены + токены ревизии + FIM
BASE_SPECIAL = ["<pad>", "<unk>", "<bos>", "<eos>"]
ALL_SPECIAL = BASE_SPECIAL + SPECIAL_TOKENS + FIM_TOKENS   # +<REVISE>,<COMMIT>,FIM


def train(input_files, out_path, vocab_size):
    tok = Tokenizer(models.BPE(unk_token="<unk>"))
    tok.pre_tokenizer = pre_tokenizers.ByteLevel(add_prefix_space=False)
    tok.decoder = decoders.ByteLevel()
    trainer = trainers.BpeTrainer(
        vocab_size=vocab_size,
        special_tokens=ALL_SPECIAL,
        show_progress=True,
    )
    tok.train(input_files, trainer)
    tok.save(out_path)
    print(f"Saved tokenizer to {out_path}")
    print("Special token ids:")
    for t in ALL_SPECIAL:
        print(f"  {t}: {tok.token_to_id(t)}")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", nargs="+", required=True, help="txt файл(ы) для обучения BPE")
    ap.add_argument("--out", default="tokenizer.json")
    ap.add_argument("--vocab_size", type=int, default=32000)
    args = ap.parse_args()
    train(args.input, args.out, args.vocab_size)
