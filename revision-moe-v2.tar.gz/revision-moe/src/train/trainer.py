"""Общий трейнер: LR-расписание, AMP, grad accumulation, clipping, чекпойнты."""
import math
import os
import time
import torch


def get_lr(step, cfg):
    warmup = cfg["warmup_steps"]
    max_steps = cfg["max_steps"]
    lr, min_lr = cfg["lr"], cfg["min_lr"]
    if step < warmup:
        return lr * (step + 1) / warmup
    if step >= max_steps:
        return min_lr
    ratio = (step - warmup) / max(1, (max_steps - warmup))
    coeff = 0.5 * (1 + math.cos(math.pi * ratio))
    return min_lr + coeff * (lr - min_lr)


def make_optimizer(model, cfg):
    decay, no_decay = [], []
    for n, p in model.named_parameters():
        if not p.requires_grad:
            continue
        (no_decay if p.dim() < 2 else decay).append(p)
    groups = [
        {"params": decay, "weight_decay": cfg["weight_decay"]},
        {"params": no_decay, "weight_decay": 0.0},
    ]
    return torch.optim.AdamW(groups, lr=cfg["lr"],
                             betas=(cfg["beta1"], cfg["beta2"]))


class Trainer:
    def __init__(self, model, optimizer, cfg, loss_fn):
        self.model = model
        self.opt = optimizer
        self.cfg = cfg
        self.loss_fn = loss_fn          # callable(batch, model) -> (loss, comps)
        self.device = cfg["device"]
        self.dtype = {"bfloat16": torch.bfloat16,
                      "float16": torch.float16,
                      "float32": torch.float32}[cfg["dtype"]]
        self.use_amp = self.dtype in (torch.bfloat16, torch.float16) and self.device == "cuda"
        self.scaler = torch.amp.GradScaler("cuda", enabled=(self.dtype == torch.float16))
        os.makedirs(cfg["out_dir"], exist_ok=True)

    def save(self, step, tag="ckpt"):
        path = os.path.join(self.cfg["out_dir"], f"{tag}_{step}.pt")
        torch.save({"model": self.model.state_dict(),
                    "cfg": self.cfg, "step": step}, path)
        print(f"[ckpt] saved {path}")

    def train(self, loader, max_steps=None):
        max_steps = max_steps or self.cfg["max_steps"]
        accum = self.cfg["grad_accum_steps"]
        self.model.train()
        step = 0
        t0 = time.time()
        data_iter = iter(loader)

        while step < max_steps:
            lr = get_lr(step, self.cfg)
            for g in self.opt.param_groups:
                g["lr"] = lr

            self.opt.zero_grad(set_to_none=True)
            agg = {}
            for _ in range(accum):
                try:
                    batch = next(data_iter)
                except StopIteration:
                    data_iter = iter(loader)
                    batch = next(data_iter)

                ctx = torch.autocast(device_type="cuda", dtype=self.dtype) \
                    if self.use_amp else torch.enable_grad()
                with ctx:
                    loss, comps = self.loss_fn(batch, self.model)
                    loss = loss / accum
                self.scaler.scale(loss).backward()
                for k, v in comps.items():
                    agg[k] = agg.get(k, 0) + v / accum

            self.scaler.unscale_(self.opt)
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), self.cfg["grad_clip"])
            self.scaler.step(self.opt)
            self.scaler.update()

            if step % self.cfg["log_interval"] == 0:
                dt = time.time() - t0
                comps_str = " ".join(f"{k}={v:.4f}" for k, v in agg.items())
                print(f"step {step:6d} | lr {lr:.2e} | {comps_str} | {dt:.1f}s")
                t0 = time.time()

            if step > 0 and step % self.cfg["ckpt_interval"] == 0:
                self.save(step)

            step += 1

        self.save(step, tag="final")
