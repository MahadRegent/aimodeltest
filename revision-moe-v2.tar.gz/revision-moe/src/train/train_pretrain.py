"""Этап A: претрейн MoE-базы как обычной языковой модели (без ревизии).

Использование:
  python -m src.train.train_pretrain \
      --model_config configs/model_tiny.yaml \
      --train_config configs/train.yaml
"""
import argparse
import yaml
import torch
from torch.utils.data import DataLoader

from src.model.model import RevisionMoE
from src.data.dataloader import PretrainDataset
from src.train.losses import total_loss
from src.train.trainer import Trainer, make_optimizer


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model_config", required=True)
    ap.add_argument("--train_config", required=True)
    args = ap.parse_args()

    mcfg = yaml.safe_load(open(args.model_config))["model"]
    tcfg = yaml.safe_load(open(args.train_config))["train"]
    torch.manual_seed(tcfg["seed"])

    model = RevisionMoE(mcfg).to(tcfg["device"])
    print(f"Параметров: {model.num_params():,}")
    if tcfg.get("compile", False):
        print("torch.compile... (первый шаг будет медленным)")
        model = torch.compile(model)

    ds = PretrainDataset(f"{tcfg['data_dir']}/train.bin", tcfg["seq_len"])
    loader = DataLoader(ds, batch_size=tcfg["batch_size"], shuffle=True,
                        num_workers=tcfg.get("num_workers", 4), drop_last=True,
                        pin_memory=True)

    def loss_fn(batch, model):
        x, y = batch
        x, y = x.to(tcfg["device"]), y.to(tcfg["device"])
        out = model(x, return_confidence=False)
        # на этапе A confidence не учим
        return total_loss(out, y, alpha=0.0,
                          beta=tcfg["moe_aux_weight"], use_confidence=False)

    opt = make_optimizer(model, tcfg)
    trainer = Trainer(model, opt, tcfg, loss_fn)
    trainer.train(loader)


if __name__ == "__main__":
    main()
