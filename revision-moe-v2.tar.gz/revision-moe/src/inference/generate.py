"""Генерация с откатами (revision) и обязательным анти-зацикливанием.

Два механизма отката:
  1) модель сама эмитит токен <REVISE>;
  2) confidence нового токена падает ниже conf_threshold (форсированный откат).

Режимы:
  - baseline=True  : обычная авторегрессия, откаты выключены (для сравнения).
  - baseline=False : откаты включены.

Предохранители от бесконечного цикла:
  - max_reverts_per_pos: лимит откатов к одной позиции;
  - после исчерпания лимита позиция "отпускается".
"""
import torch
import torch.nn.functional as F

from src.model.revision import REVISE_TOKEN, find_revision_target
from src.inference.kv_cache import trim_kv_caches


def _do_revert(tokens, confidences, kv, target, tok, device, baseline, model):
    """Выполняет откат до позиции target: режет токены/кэш и делает префилл."""
    tokens = tokens[:target]
    confidences = confidences[:target]
    kv = trim_kv_caches(kv, target)
    if len(tokens) == 0:
        tokens = [tok.token_to_id("<bos>") or 0]
        confidences = [1.0]
    x = torch.tensor([tokens], device=device)
    out = model(x, return_confidence=not baseline)
    return tokens, confidences, out["new_kv_caches"], out


@torch.no_grad()
def generate(model, tok, prompt, max_new_tokens=200, temperature=0.8, top_k=50,
             baseline=False, conf_threshold=0.3, revise_window=16,
             max_reverts_per_pos=3, device="cuda", verbose=False,
             post_revert_temp_boost=1.3):
    model.eval()
    revise_id = tok.token_to_id(REVISE_TOKEN)
    eos_id = tok.token_to_id("<eos>")

    ids = tok.encode(prompt).ids
    tokens = list(ids)
    confidences = [1.0] * len(tokens)
    revert_counts = {}
    cur_temp = temperature

    # префилл
    x = torch.tensor([tokens], device=device)
    out = model(x, return_confidence=not baseline)
    kv = out["new_kv_caches"]

    steps = 0
    while steps < max_new_tokens:
        last_logits = out["logits"][:, -1, :] / cur_temp
        if top_k:
            v, _ = torch.topk(last_logits, top_k)
            last_logits[last_logits < v[:, [-1]]] = -float("inf")
        probs = F.softmax(last_logits, dim=-1)
        next_id = int(torch.multinomial(probs, 1).item())

        # ---- откат по токену <REVISE> ----
        if not baseline and next_id == revise_id:
            target = find_revision_target(confidences, revise_window)
            rc = revert_counts.get(target, 0)
            if rc < max_reverts_per_pos:
                revert_counts[target] = rc + 1
                if verbose:
                    print(f"  [REVISE-tok] откат к позиции {target} "
                          f"(попытка {rc+1}/{max_reverts_per_pos})")
                tokens, confidences, kv, out = _do_revert(
                    tokens, confidences, kv, target, tok, device, baseline, model)
                cur_temp = temperature * post_revert_temp_boost  # разнообразим регенерацию
                steps += 1
                continue
            else:
                if verbose:
                    print(f"  [REVISE заблокирован] позиция {target} достигла лимита "
                          f"{max_reverts_per_pos} (анти-зацикливание)")
                probs[0, revise_id] = 0
                next_id = int(torch.multinomial(probs, 1).item())

        # ---- принятие токена ----
        tokens.append(next_id)
        if not baseline and out["confidence_logit"] is not None:
            conf = torch.sigmoid(out["confidence_logit"][:, -1]).item()
        else:
            conf = 1.0
        confidences.append(conf)

        if next_id == eos_id:
            break

        # ---- форсированный откат по низкой confidence ----
        if not baseline and conf < conf_threshold and len(tokens) > 2:
            target = find_revision_target(confidences, revise_window)
            rc = revert_counts.get(target, 0)
            if rc < max_reverts_per_pos:
                revert_counts[target] = rc + 1
                if verbose:
                    print(f"  [CONF-REVISE] conf={conf:.3f} < {conf_threshold} "
                          f"-> откат к позиции {target} (попытка {rc+1})")
                tokens, confidences, kv, out = _do_revert(
                    tokens, confidences, kv, target, tok, device, baseline, model)
                cur_temp = temperature * post_revert_temp_boost
                steps += 1
                continue

        cur_temp = temperature  # сброс температуры после успешного токена

        # forward на один новый токен с кэшем
        x = torch.tensor([[next_id]], device=device)
        pos = len(tokens) - 1
        out = model(x, kv_caches=kv, pos_offset=pos, return_confidence=not baseline)
        kv = out["new_kv_caches"]
        steps += 1

    if verbose and not baseline:
        total = sum(revert_counts.values())
        print(f"  [ИТОГО] откатов: {total}, затронуто позиций: {len(revert_counts)}")

    return tok.decode(tokens), tokens, confidences


if __name__ == "__main__":
    import argparse, yaml
    from tokenizers import Tokenizer
    from src.model.model import RevisionMoE

    ap = argparse.ArgumentParser()
    ap.add_argument("--ckpt", required=True)
    ap.add_argument("--model_config", required=True)
    ap.add_argument("--tokenizer", required=True)
    ap.add_argument("--prompt", default="Once upon a time")
    ap.add_argument("--baseline", action="store_true")
    ap.add_argument("--verbose", action="store_true")
    ap.add_argument("--temperature", type=float, default=0.8)
    ap.add_argument("--conf_threshold", type=float, default=0.3)
    ap.add_argument("--max_new_tokens", type=int, default=200)
    ap.add_argument("--device", default="cuda")
    args = ap.parse_args()

    mcfg = yaml.safe_load(open(args.model_config))["model"]
    model = RevisionMoE(mcfg).to(args.device)
    model.load_state_dict(torch.load(args.ckpt, map_location=args.device)["model"])
    tok = Tokenizer.from_file(args.tokenizer)

    text, _, _ = generate(model, tok, args.prompt, baseline=args.baseline,
                          device=args.device, verbose=args.verbose,
                          temperature=args.temperature,
                          conf_threshold=args.conf_threshold,
                          max_new_tokens=args.max_new_tokens)
    print("---")
    print(text)
