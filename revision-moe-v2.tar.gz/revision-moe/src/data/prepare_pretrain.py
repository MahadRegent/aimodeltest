"""Подготовка корпуса: фильтрация -> ПАРАЛЛЕЛЬНЫЙ MinHash-дедуп -> токенизация -> .bin.

Вход:  один или несколько .txt/.jsonl файлов или директорий (по документу на строку;
       для .jsonl берётся поле --text_field, по умолчанию "text").
Выход: data/processed/train.bin, val.bin (uint16 поток токенов).

Использование:
  python -m src.data.prepare_pretrain \
      --input data/raw \
      --tokenizer tokenizer.json \
      --out_dir data/processed \
      --workers 0            # 0 = все ядра
"""
import argparse
import glob
import json
import os
from multiprocessing import Pool, cpu_count
import numpy as np
from tqdm import tqdm
from tokenizers import Tokenizer

try:
    from datasketch import MinHash, MinHashLSH
    HAS_DATASKETCH = True
except ImportError:
    HAS_DATASKETCH = False


def _gather_files(paths):
    files = []
    for p in paths:
        if os.path.isdir(p):
            files += glob.glob(os.path.join(p, "**", "*.txt"), recursive=True)
            files += glob.glob(os.path.join(p, "**", "*.jsonl"), recursive=True)
        else:
            files.append(p)
    return sorted(set(files))


def iter_docs(paths, text_field="text"):
    for p in _gather_files(paths):
        is_jsonl = p.endswith(".jsonl")
        with open(p, "r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                if is_jsonl:
                    try:
                        obj = json.loads(line)
                        text = obj.get(text_field, "")
                    except json.JSONDecodeError:
                        continue
                    if text:
                        yield text.replace("\n", " ").strip()
                else:
                    yield line


def basic_filter(doc, min_len=64, max_symbol_ratio=0.5):
    """Эвристики качества. Мягкие, чтобы не выкинуть код (в нём много символов)."""
    if len(doc) < min_len:
        return False
    alpha = sum(c.isalpha() or c.isspace() for c in doc)
    if alpha / max(len(doc), 1) < (1 - max_symbol_ratio):
        return False
    return True


def _sig_worker(args):
    """Воркер для Pool: MinHash-сигнатура одного документа. Верхний уровень — picklable."""
    i, text, num_perm = args
    m = MinHash(num_perm=num_perm)
    shingles = {text[j:j + 5] for j in range(0, max(len(text) - 5, 1))}
    for sh in shingles:
        m.update(sh.encode("utf-8"))
    return i, m


def dedup(docs, threshold=0.8, num_perm=64, workers=None):
    """Параллельная near-dup дедупликация (MinHash+LSH)."""
    if not HAS_DATASKETCH:
        print("[warn] datasketch не установлен — пропускаю дедупликацию")
        return docs
    workers = workers or cpu_count()
    print(f"dedup: MinHash на {workers} ядрах для {len(docs):,} документов...")

    # 1) ПАРАЛЛЕЛЬНО считаем сигнатуры (самая тяжёлая часть)
    tasks = ((i, doc, num_perm) for i, doc in enumerate(docs))
    sigs = [None] * len(docs)
    with Pool(workers) as pool:
        for i, m in tqdm(pool.imap_unordered(_sig_worker, tasks, chunksize=256),
                         total=len(docs), desc="minhash"):
            sigs[i] = m

    # 2) ПОСЛЕДОВАТЕЛЬНО вставляем в LSH (дёшево, LSH не потокобезопасен)
    lsh = MinHashLSH(threshold=threshold, num_perm=num_perm)
    kept = []
    for i, m in enumerate(tqdm(sigs, desc="lsh")):
        if not lsh.query(m):
            lsh.insert(f"d{i}", m)
            kept.append(docs[i])
    print(f"dedup: {len(docs):,} -> {len(kept):,} документов")
    return kept


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", nargs="+", required=True,
                    help="файлы или директории (.txt построчно или .jsonl)")
    ap.add_argument("--tokenizer", required=True)
    ap.add_argument("--out_dir", default="data/processed")
    ap.add_argument("--text_field", default="text")
    ap.add_argument("--val_frac", type=float, default=0.005)
    ap.add_argument("--workers", type=int, default=0, help="0 = все ядра")
    ap.add_argument("--no_dedup", action="store_true")
    args = ap.parse_args()

    os.makedirs(args.out_dir, exist_ok=True)
    tok = Tokenizer.from_file(args.tokenizer)
    eos_id = tok.token_to_id("<eos>")
    workers = args.workers or cpu_count()

    print("Загрузка и фильтрация...")
    docs = [d for d in tqdm(iter_docs(args.input, args.text_field), desc="load")
            if basic_filter(d)]
    print(f"После фильтрации: {len(docs):,} документов")

    if not args.no_dedup:
        docs = dedup(docs, workers=workers)

    print(f"Токенизация на {workers} ядрах...")
    # батч-токенизация (tokenizers сам параллелит внутри)
    all_ids = []
    B = 10000
    for s in tqdm(range(0, len(docs), B), desc="tokenize"):
        batch = docs[s:s + B]
        for enc in tok.encode_batch(batch):
            all_ids.extend(enc.ids)
            all_ids.append(eos_id)

    arr = np.array(all_ids, dtype=np.uint16)
    n_val = int(len(arr) * args.val_frac)
    val, train = arr[:n_val], arr[n_val:]

    train.tofile(os.path.join(args.out_dir, "train.bin"))
    val.tofile(os.path.join(args.out_dir, "val.bin"))
    print(f"train: {len(train):,} токенов -> train.bin")
    print(f"val:   {len(val):,} токенов -> val.bin")


if __name__ == "__main__":
    main()
