# Revision-MoE

Decoder-only **MoE** языковая модель, которая **сама учится** оценивать уверенность в уже сгенерированном тексте и **откатываться** (backtracking) для перегенерации, когда уверенность падает. Откат запускается спецтокеном `<REVISE>`, который модель эмитит сама, а уверенность предсказывает отдельная **голова уверенности**, опирающаяся в том числе на **рассогласование экспертов MoE**.

> Это **исследовательский PoC**, не «конкурент GPT». Цель — на модели 10–100M параметров показать, что механизм ревизии улучшает качество против обычного авторегрессионного бейзлайна. Это реально на 1 GPU.

---

## Что внутри

```
revision-moe/
├── configs/                 # YAML-конфиги модели и обучения
│   ├── model_tiny.yaml      # ~10M, для отладки на TinyStories
│   ├── model_small.yaml     # ~50-100M, основной PoC
│   └── train.yaml           # гиперпараметры обучения
├── data/                    # СЮДА КЛАДЁТСЯ ДАТАСЕТ (см. ниже)
│   ├── raw/                 # сырые тексты (corpus.txt)
│   ├── processed/           # токенизированные .bin шарды
│   ├── revision_traces/     # трейсы с откатами (traces.jsonl)
│   └── eval_prompts.txt     # промпты для финального сравнения
├── src/
│   ├── tokenizer/           # обучение BPE + спецтокены <REVISE>,<COMMIT>
│   ├── model/               # attention(GQA+RoPE), moe, confidence_head, model
│   ├── data/                # подготовка претрейна + генерация revision-traces
│   ├── train/               # losses, trainer, скрипты этапов A и B
│   ├── inference/           # генерация с откатами + KV-кэш
│   └── eval/                # perplexity + сравнение ревизия vs бейзлайн
├── scripts/                 # download_tinystories, run_pretrain, run_revision
└── tests/                   # pytest: модель, MoE, KV-кэш, ревизия
```

---

## Установка

```bash
cd revision-moe
python -m venv .venv && source .venv/bin/activate
pip install -e .            # ставит зависимости из pyproject.toml
# для GPU поставь torch под свою CUDA с https://pytorch.org
```

Проверь, что всё цело:
```bash
pytest tests/ -q            # должно быть 7 passed
```

---

## Куда класть датасет и как его делать

Весь датасет живёт в `data/`. Нужны **две разные вещи**:

### (1) Претрейн-корпус — обычный текст

Положи сырой текст в `data/raw/corpus.txt` — **по одному документу на строку**.

Быстрый старт на TinyStories (модель 10M реально учится на нём):
```bash
python -m scripts.download_tinystories --n 50000
# -> data/raw/corpus.txt
```
Свой корпус — просто положи `.txt` (по документу на строку) в `data/raw/`. Для серьёзного PoC бери sample из **FineWeb-Edu** или **The Stack** и сложи в тот же формат.

### (2) Revision-traces — данные, обучающие откатам ⭐

Это **сердце проекта**. Таких данных нет в природе — их конструируют. Два способа:

**Быстрый (синтетическая порча текста) — для старта:**
```bash
python -m src.data.build_revision_data \
    --mode synthetic_corrupt \
    --input data/raw/corpus.txt \
    --tokenizer tokenizer.json \
    --out data/revision_traces/traces.jsonl
```
Берёт чистый текст, вставляет «мусорный» фрагмент, помечает его low-confidence и ставит `<REVISE>` перед корректным продолжением.

**Качественный (из пар черновик→исправление):**
Подготовь `pairs.jsonl`, по строке `{"draft": "...", "fixed": "..."}` (например, из diff-ов коммитов кода, правок вики, или ответов, отбракованных проверкой). Затем:
```bash
python -m src.data.build_revision_data \
    --mode from_pairs \
    --input pairs.jsonl \
    --tokenizer tokenizer.json \
    --out data/revision_traces/traces.jsonl
```

Формат каждого трейса (JSONL):
```json
{"tokens": [..], "confidence_labels": [1,1,..,0,0,..,1,1], "revise_at": 42}
```

---

## Полный пайплайн: от данных до результата

### Шаг 0. Токенизатор (один раз)
```bash
python -m src.tokenizer.train_tokenizer \
    --input data/raw/corpus.txt \
    --out tokenizer.json --vocab_size 32000
```
Выведет id спецтокенов `<REVISE>`, `<COMMIT>`. **Важно:** `vocab_size` в `configs/model_*.yaml` должен совпадать с реальным размером словаря токенизатора.

### Шаг 1. Подготовить претрейн-данные
```bash
python -m src.data.prepare_pretrain \
    --input data/raw/corpus.txt \
    --tokenizer tokenizer.json \
    --out_dir data/processed
# -> data/processed/train.bin, val.bin  (с дедупликацией MinHash)
```

### Шаг 2. Этап A — претрейн MoE-базы (без ревизии)
```bash
bash scripts/run_pretrain.sh
# или напрямую:
python -m src.train.train_pretrain \
    --model_config configs/model_tiny.yaml \
    --train_config configs/train.yaml
# чекпойнты -> checkpoints/
```
Следи в логах за `lm` (должен падать) и `aux` (load-balancing, не должен расти). Критерий перехода: связный текст, разумная perplexity.

### Шаг 3. Сделать revision-traces
(см. раздел выше — `build_revision_data`)

### Шаг 4. Этап B — обучить ревизию
```bash
bash scripts/run_revision.sh checkpoints/final_20000.pt
# или:
python -m src.train.train_revision \
    --model_config configs/model_tiny.yaml \
    --train_config configs/train.yaml \
    --init checkpoints/final_20000.pt --lr 5e-5
```
Теперь активен `confidence`-лосс: голова учится предсказывать уверенность, модель — эмитить `<REVISE>`.

### Шаг 5. Генерация с откатами
```bash
# с ревизией:
python -m src.inference.generate \
    --ckpt checkpoints/final_20000.pt \
    --model_config configs/model_tiny.yaml \
    --tokenizer tokenizer.json \
    --prompt "Once upon a time" --device cuda

# бейзлайн (откаты выключены) — для сравнения:
python -m src.inference.generate ... --baseline
```

### Шаг 6. Главный замер — ревизия против бейзлайна
```bash
python -m src.eval.eval_revision \
    --ckpt checkpoints/final_20000.pt \
    --model_config configs/model_tiny.yaml \
    --tokenizer tokenizer.json \
    --prompts data/eval_prompts.txt --device cuda
```
Если `revision avg NLL < baseline avg NLL` — **идея доказана**. Для задач код/математика подключи pass-rate вместо self-NLL (место отмечено в `eval_revision.py`).

Perplexity на val:
```bash
python -m src.eval.eval_lm \
    --ckpt checkpoints/final_20000.pt \
    --model_config configs/model_tiny.yaml \
    --train_config configs/train.yaml
```

---

## Как устроен механизм (кратко)

- **MoE** (`src/model/moe.py`): top-k роутинг + load-balancing loss. Дополнительно возвращает **дисперсию между выбранными экспертами** — высокая дисперсия = «эксперты не согласны» = сигнал неуверенности.
- **Голова уверенности** (`src/model/confidence_head.py`): на вход скрытое состояние + энтропия логитов + дисперсия экспертов → confidence ∈ [0,1].
- **Ревизия** (`src/inference/generate.py`): когда модель эмитит `<REVISE>`, рантайм находит позицию минимальной уверенности в окне, **обрезает KV-кэш** до неё и продолжает генерацию.
- **Анти-зацикливание** (обязательно!): лимит откатов на позицию + смягчение порога. Без этого модель уходит в бесконечные откаты — самая частая ошибка.

---

## Масштаб и ожидания

| Конфиг | Железо | Время | Результат |
|---|---|---|---|
| `model_tiny` (~10M) + TinyStories | 1× 3090/4090 | часы | пайплайн работает, связный текст |
| `model_small` (~50-100M) | 1× A100/4090 | дни | **выигрыш ревизии над бейзлайном — главный результат** |

На 50-100M модель не будет «умной», но вполне может **статистически значимо** показать, что ревизия снижает perplexity / повышает pass-rate. Это и есть успех PoC.

---

## Частые проблемы

- **`vocab_size` mismatch** → приведи конфиг к размеру токенизатора.
- **Роутер MoE коллапсирует** (один эксперт) → увеличь `moe_aux_weight`, проверь логи загрузки.
- **Бесконечные откаты** → уменьши `max_reverts_per_pos`, проверь анти-зацикливание.
- **Голова уверенности переуверена** → увеличь `label_smoothing` в `confidence_loss`.
- **CUDA OOM** → уменьши `batch_size`, увеличь `grad_accum_steps`.
- **Нет GPU** → поставь `device: cpu` в `train.yaml` (только для `model_tiny` и отладки).

---

## Лицензия / данные

Код — твой. Следи за лицензиями датасетов (TinyStories, FineWeb, The Stack — у каждого свои условия).
