"""Скачивает небольшой кусок TinyStories и кладёт в data/raw/corpus.txt
для быстрого старта (модель 10M реально учится связному тексту на нём).

Использование:
  python -m scripts.download_tinystories --n 50000
"""
import argparse
import os


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=50000, help="сколько историй взять")
    ap.add_argument("--out", default="data/raw/corpus.txt")
    args = ap.parse_args()

    from datasets import load_dataset
    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    print("Загрузка TinyStories (stream)...")
    ds = load_dataset("roneneldan/TinyStories", split="train", streaming=True)

    with open(args.out, "w", encoding="utf-8") as f:
        for i, ex in enumerate(ds):
            if i >= args.n:
                break
            text = ex["text"].replace("\n", " ").strip()
            if text:
                f.write(text + "\n")
    print(f"Сохранено {args.n} историй -> {args.out}")


if __name__ == "__main__":
    main()
