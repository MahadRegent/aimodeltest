#!/usr/bin/env bash
# Этап A: претрейн MoE-базы. Запускать из корня проекта.
set -e
python -m src.train.train_pretrain \
    --model_config configs/model_tiny.yaml \
    --train_config configs/train.yaml
