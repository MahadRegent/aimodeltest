#!/usr/bin/env bash
# Этап B: дообучение на ревизию. Укажи путь к чекпойнту этапа A.
set -e
CKPT=${1:-checkpoints/final_20000.pt}
python -m src.train.train_revision \
    --model_config configs/model_tiny.yaml \
    --train_config configs/train.yaml \
    --init "$CKPT"
