"""Логика спецтокенов ревизии.

Подход: модель эмитит токен <REVISE>, а величину отката (на сколько позиций
назад) определяет правило на инференсе — откат к позиции с минимальной
confidence в скользящем окне. Это проще и надёжнее, чем кодировать число k
в сам токен, и хорошо работает в PoC.

Спецтокены добавляются в токенизатор (см. tokenizer/train_tokenizer.py):
  <REVISE>  — сигнал «здесь что-то не так, откатываемся»
  <COMMIT>  — (опционально) «я уверен в текущем фрагменте»
"""

REVISE_TOKEN = "<REVISE>"
COMMIT_TOKEN = "<COMMIT>"
SPECIAL_TOKENS = [REVISE_TOKEN, COMMIT_TOKEN]


def find_revision_target(confidences, window, min_keep=1):
    """Выбирает позицию отката: индекс минимальной confidence в скользящем окне
    последних `window` токенов. confidences: list/tensor float по позициям.
    Возвращает индекс позиции, к которой откатываемся (всё после неё отбрасывается)."""
    n = len(confidences)
    if n <= min_keep:
        return max(0, n - 1)
    start = max(min_keep, n - window)
    seg = confidences[start:n]
    # позиция минимума внутри окна
    local_min = min(range(len(seg)), key=lambda i: seg[i])
    return start + local_min
