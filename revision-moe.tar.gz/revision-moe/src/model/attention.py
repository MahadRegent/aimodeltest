"""Grouped-Query Attention с RoPE и поддержкой KV-кэша (для инференса с откатами)."""
import math
import torch
import torch.nn as nn
import torch.nn.functional as F


def precompute_rope(dim: int, max_seq_len: int, theta: float = 10000.0):
    """Возвращает cos/sin таблицы для RoPE. dim — размер головы (должен быть чётным)."""
    inv_freq = 1.0 / (theta ** (torch.arange(0, dim, 2).float() / dim))
    t = torch.arange(max_seq_len).float()
    freqs = torch.outer(t, inv_freq)          # [seq, dim/2]
    cos = freqs.cos()
    sin = freqs.sin()
    return cos, sin                           # [seq, dim/2]


def apply_rope(x: torch.Tensor, cos: torch.Tensor, sin: torch.Tensor, pos_offset: int = 0):
    """x: [B, n_heads, T, head_dim]. Применяет rotary embedding начиная с позиции pos_offset."""
    T = x.shape[2]
    cos = cos[pos_offset:pos_offset + T]      # [T, head_dim/2]
    sin = sin[pos_offset:pos_offset + T]
    cos = cos[None, None, :, :]               # broadcast по B и heads
    sin = sin[None, None, :, :]
    x1, x2 = x[..., 0::2], x[..., 1::2]        # чётные/нечётные
    rx1 = x1 * cos - x2 * sin
    rx2 = x1 * sin + x2 * cos
    out = torch.empty_like(x)
    out[..., 0::2] = rx1
    out[..., 1::2] = rx2
    return out


class Attention(nn.Module):
    def __init__(self, dim, n_heads, n_kv_heads, max_seq_len):
        super().__init__()
        assert dim % n_heads == 0
        self.n_heads = n_heads
        self.n_kv_heads = n_kv_heads
        self.head_dim = dim // n_heads
        self.n_rep = n_heads // n_kv_heads     # сколько query-голов на одну kv-голову

        self.wq = nn.Linear(dim, n_heads * self.head_dim, bias=False)
        self.wk = nn.Linear(dim, n_kv_heads * self.head_dim, bias=False)
        self.wv = nn.Linear(dim, n_kv_heads * self.head_dim, bias=False)
        self.wo = nn.Linear(n_heads * self.head_dim, dim, bias=False)

    def forward(self, x, cos, sin, kv_cache=None, pos_offset=0):
        """
        x: [B, T, dim]
        kv_cache: dict с 'k','v' тензорами прошлых шагов, либо None.
        Возвращает (out, new_kv_cache).
        """
        B, T, _ = x.shape
        q = self.wq(x).view(B, T, self.n_heads, self.head_dim).transpose(1, 2)
        k = self.wk(x).view(B, T, self.n_kv_heads, self.head_dim).transpose(1, 2)
        v = self.wv(x).view(B, T, self.n_kv_heads, self.head_dim).transpose(1, 2)

        q = apply_rope(q, cos, sin, pos_offset)
        k = apply_rope(k, cos, sin, pos_offset)

        if kv_cache is not None and kv_cache.get("k") is not None:
            k = torch.cat([kv_cache["k"], k], dim=2)
            v = torch.cat([kv_cache["v"], v], dim=2)
        new_cache = {"k": k, "v": v}

        # GQA: повторяем kv-головы
        if self.n_rep > 1:
            k = k.repeat_interleave(self.n_rep, dim=1)
            v = v.repeat_interleave(self.n_rep, dim=1)

        # causal только когда генерим без кэша (полная последовательность) или префилл
        is_causal = kv_cache is None or kv_cache.get("k") is None
        out = F.scaled_dot_product_attention(q, k, v, is_causal=is_causal)
        out = out.transpose(1, 2).contiguous().view(B, T, -1)
        return self.wo(out), new_cache
