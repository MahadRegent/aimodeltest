"""Один трансформер-блок: pre-norm + GQA attention + (MoE или dense FFN)."""
import torch
import torch.nn as nn
import torch.nn.functional as F

from .attention import Attention
from .moe import MoE


class RMSNorm(nn.Module):
    def __init__(self, dim, eps=1e-5):
        super().__init__()
        self.eps = eps
        self.weight = nn.Parameter(torch.ones(dim))

    def forward(self, x):
        norm = x * torch.rsqrt(x.pow(2).mean(-1, keepdim=True) + self.eps)
        return norm * self.weight


class DenseFFN(nn.Module):
    """SwiGLU FFN для не-MoE слоёв."""
    def __init__(self, dim, hidden):
        super().__init__()
        self.w1 = nn.Linear(dim, hidden, bias=False)
        self.w2 = nn.Linear(hidden, dim, bias=False)
        self.w3 = nn.Linear(dim, hidden, bias=False)

    def forward(self, x):
        return self.w2(F.silu(self.w1(x)) * self.w3(x))


class Block(nn.Module):
    def __init__(self, cfg, is_moe: bool):
        super().__init__()
        dim = cfg["dim"]
        self.attn_norm = RMSNorm(dim, cfg["norm_eps"])
        self.attn = Attention(dim, cfg["n_heads"], cfg["n_kv_heads"], cfg["max_seq_len"])
        self.ffn_norm = RMSNorm(dim, cfg["norm_eps"])
        self.is_moe = is_moe
        if is_moe:
            self.ffn = MoE(dim, cfg["expert_hidden"], cfg["n_experts"], cfg["top_k"])
        else:
            self.ffn = DenseFFN(dim, cfg["ffn_hidden"])

    def forward(self, x, cos, sin, kv_cache=None, pos_offset=0):
        h, new_cache = self.attn(self.attn_norm(x), cos, sin, kv_cache, pos_offset)
        x = x + h
        if self.is_moe:
            ffn_out, aux_loss, expert_var = self.ffn(self.ffn_norm(x))
            x = x + ffn_out
            return x, new_cache, aux_loss, expert_var
        else:
            x = x + self.ffn(self.ffn_norm(x))
            return x, new_cache, None, None
