"""Голова уверенности. Предсказывает per-token confidence in [0,1] —
вероятность того, что токен корректен и не будет откачен. На вход —
скрытое состояние + entropy логитов + дисперсия экспертов MoE."""
import torch
import torch.nn as nn
import torch.nn.functional as F


class ConfidenceHead(nn.Module):
    def __init__(self, dim, hidden):
        super().__init__()
        # +2 входа: entropy логитов и expert_variance
        self.net = nn.Sequential(
            nn.Linear(dim + 2, hidden),
            nn.GELU(),
            nn.Linear(hidden, 1),
        )

    def forward(self, hidden, logits, expert_var):
        """
        hidden:      [B, T, dim]   скрытое состояние с последнего слоя
        logits:      [B, T, vocab] выход LM-головы (для энтропии)
        expert_var:  [B, T]        дисперсия экспертов (0 если нет MoE-сигнала)
        Возвращает confidence_logit [B, T] (применяй sigmoid для вероятности).
        """
        probs = F.softmax(logits, dim=-1)
        entropy = -(probs * torch.log(probs + 1e-9)).sum(dim=-1)   # [B, T]
        # нормируем энтропию на log(vocab) -> [0,1]
        entropy = entropy / torch.log(torch.tensor(logits.shape[-1], dtype=entropy.dtype, device=entropy.device))

        feats = torch.cat([
            hidden,
            entropy.unsqueeze(-1),
            expert_var.unsqueeze(-1),
        ], dim=-1)
        return self.net(feats).squeeze(-1)        # [B, T]
