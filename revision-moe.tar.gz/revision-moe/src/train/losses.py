"""Функции потерь: LM-loss + confidence-loss + MoE aux-loss.
Итог: L = L_lm + alpha * L_confidence + beta * L_moe_aux
"""
import torch
import torch.nn.functional as F


def lm_loss(logits, targets, ignore_index=-100):
    """Стандартный next-token cross-entropy.
    logits: [B, T, V], targets: [B, T]."""
    B, T, V = logits.shape
    return F.cross_entropy(
        logits.reshape(B * T, V),
        targets.reshape(B * T),
        ignore_index=ignore_index,
    )


def confidence_loss(confidence_logit, conf_labels, mask, label_smoothing=0.05):
    """BCE между предсказанной уверенностью и метками (1=токен корректен, 0=будет откачен).
    confidence_logit: [B, T], conf_labels: [B, T] in {0,1}, mask: [B,T] bool (где считать).
    label_smoothing уменьшает переуверенность головы (важно для калибровки)."""
    if mask.sum() == 0:
        return torch.tensor(0.0, device=confidence_logit.device)
    target = conf_labels.float()
    # сглаживание меток: 0->eps, 1->1-eps
    target = target * (1 - 2 * label_smoothing) + label_smoothing
    loss = F.binary_cross_entropy_with_logits(
        confidence_logit[mask], target[mask], reduction="mean"
    )
    return loss


def total_loss(out, targets, conf_labels=None, conf_mask=None,
               alpha=0.5, beta=0.01, use_confidence=False):
    """Собирает полный лосс из выхода модели."""
    l_lm = lm_loss(out["logits"], targets)
    l_aux = out["aux_loss"]
    aux_val = l_aux.detach().item() if hasattr(l_aux, "detach") else float(l_aux)
    components = {"lm": l_lm.detach().item(), "aux": aux_val}
    loss = l_lm + beta * l_aux

    if use_confidence and out["confidence_logit"] is not None and conf_labels is not None:
        l_conf = confidence_loss(out["confidence_logit"], conf_labels, conf_mask)
        loss = loss + alpha * l_conf
        components["confidence"] = l_conf.detach().item()

    return loss, components
