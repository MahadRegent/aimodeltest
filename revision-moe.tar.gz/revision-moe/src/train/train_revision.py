"""Этап B: дообучение на revision-traces — модель учится эмитить <REVISE>
и предсказывать confidence. Стартует от чекпойнта этапа A.

Использование:
  python -m src.train.train_revision \
      --model_config configs/model_tiny.yaml \
      --train_config configs/train.yaml \
      --init checkpoints/final_20000.pt
"""
import argparse
import yaml
import torch
from torch.utils.data import DataLoader

from src.model.model import RevisionMoE
from src.data.dataloader import RevisionDataset
from src.train.losses import total_loss
from src.train.trainer import Trainer, make_optimizer


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model_config", required=True)
    ap.add_argument("--train_config", required=True)
    ap.add_argument("--init", required=True, help="чекпойнт этапа A")
    ap.add_argument("--lr", type=float, default=5e-5, help="меньший LR для дообучения")
    args = ap.parse_args()

    mcfg = yaml.safe_load(open(args.model_config))["model"]
    tcfg = yaml.safe_load(open(args.train_config))["train"]
    tcfg["lr"] = args.lr          # дообучение с меньшим LR
    tcfg["min_lr"] = args.lr / 10
    torch.manual_seed(tcfg["seed"])

    model = RevisionMoE(mcfg).to(tcfg["device"])
    ckpt = torch.load(args.init, map_location=tcfg["device"])
    model.load_state_dict(ckpt["model"], strict=False)  # confidence head может быть новой
    print(f"Загружен чекпойнт {args.init}")

    ds = RevisionDataset(tcfg["revision_data"], tcfg["seq_len"])
    loader = DataLoader(ds, batch_size=tcfg["batch_size"], shuffle=True,
                        num_workers=2, drop_last=True)

    def loss_fn(batch, model):
        x, y, c, mask = [t.to(tcfg["device"]) for t in batch]
        out = model(x, return_confidence=True)
        return total_loss(out, y, conf_labels=c, conf_mask=mask,
                          alpha=tcfg["confidence_weight"],
                          beta=tcfg["moe_aux_weight"], use_confidence=True)

    opt = make_optimizer(model, tcfg)
    trainer = Trainer(model, opt, tcfg, loss_fn)
    trainer.train(loader)


if __name__ == "__main__":
    main()
