"""Загрузчики данных.

PretrainDataset — читает .bin поток токенов, нарезает блоки seq_len (next-token).
RevisionDataset — читает traces.jsonl, отдаёт токены + confidence-метки + маску.
"""
import json
import numpy as np
import torch
from torch.utils.data import Dataset


class PretrainDataset(Dataset):
    """Берёт непрерывный поток токенов из .bin и нарезает на блоки длины seq_len."""
    def __init__(self, bin_path, seq_len):
        self.data = np.memmap(bin_path, dtype=np.uint16, mode="r")
        self.seq_len = seq_len

    def __len__(self):
        return max(0, (len(self.data) - 1) // self.seq_len)

    def __getitem__(self, i):
        s = i * self.seq_len
        x = self.data[s:s + self.seq_len].astype(np.int64)
        y = self.data[s + 1:s + 1 + self.seq_len].astype(np.int64)
        return torch.from_numpy(x), torch.from_numpy(y)


class RevisionDataset(Dataset):
    """Трейсы с откатами. Возвращает (x, y, conf_labels, conf_mask).
    conf_mask=1 на позициях, где считаем confidence-loss (все реальные токены)."""
    def __init__(self, jsonl_path, seq_len, pad_id=0):
        self.items = []
        with open(jsonl_path, "r", encoding="utf-8") as f:
            for line in f:
                self.items.append(json.loads(line))
        self.seq_len = seq_len
        self.pad_id = pad_id

    def __len__(self):
        return len(self.items)

    def __getitem__(self, i):
        obj = self.items[i]
        tokens = obj["tokens"][:self.seq_len + 1]
        conf = obj["confidence_labels"][:self.seq_len + 1]

        x = tokens[:-1]
        y = tokens[1:]
        # confidence-метка относится к токену на позиции -> сдвигаем под x
        c = conf[:-1]

        L = len(x)
        pad = self.seq_len - L
        if pad > 0:
            x = x + [self.pad_id] * pad
            y = y + [-100] * pad          # игнор в LM-loss
            c = c + [0] * pad
        mask = [1] * L + [0] * max(pad, 0)

        return (
            torch.tensor(x[:self.seq_len], dtype=torch.long),
            torch.tensor(y[:self.seq_len], dtype=torch.long),
            torch.tensor(c[:self.seq_len], dtype=torch.long),
            torch.tensor(mask[:self.seq_len], dtype=torch.bool),
        )
