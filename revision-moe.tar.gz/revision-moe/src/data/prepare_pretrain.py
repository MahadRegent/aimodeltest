"""Подготовка претрейн-корпуса: фильтрация -> MinHash-дедуп -> токенизация -> .bin шарды.

Вход:  data/raw/*.txt  (по документу на строку, либо большие текстовые файлы)
Выход: data/processed/train.bin, data/processed/val.bin  (uint16 поток токенов)

Использование:
  python -m src.data.prepare_pretrain \
      --input data/raw/corpus.txt \
      --tokenizer tokenizer.json \
      --out_dir data/processed
"""
import argparse
import os
import numpy as np
from tqdm import tqdm
from tokenizers import Tokenizer

try:
    from datasketch import MinHash, MinHashLSH
    HAS_DATASKETCH = True
except ImportError:
    HAS_DATASKETCH = False


def iter_docs(paths):
    for p in paths:
        with open(p, "r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                line = line.strip()
                if line:
                    yield line


def basic_filter(doc, min_len=64, max_symbol_ratio=0.3):
    """Простейшие эвристики качества."""
    if len(doc) < min_len:
        return False
    alpha = sum(c.isalpha() or c.isspace() for c in doc)
    if alpha / max(len(doc), 1) < (1 - max_symbol_ratio):
        return False
    return True


def minhash_sig(text, num_perm=64):
    m = MinHash(num_perm=num_perm)
    for shingle in {text[i:i + 5] for i in range(0, max(len(text) - 5, 1))}:
        m.update(shingle.encode("utf-8"))
    return m


def dedup(docs, threshold=0.8):
    """Near-dup дедупликация через MinHash+LSH. Возвращает уникальные документы."""
    if not HAS_DATASKETCH:
        print("[warn] datasketch не установлен — пропускаю дедупликацию")
        return docs
    lsh = MinHashLSH(threshold=threshold, num_perm=64)
    kept = []
    for i, doc in enumerate(tqdm(docs, desc="dedup")):
        sig = minhash_sig(doc)
        if not lsh.query(sig):
            lsh.insert(f"d{i}", sig)
            kept.append(doc)
    print(f"dedup: {len(docs)} -> {len(kept)} документов")
    return kept


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", nargs="+", required=True)
    ap.add_argument("--tokenizer", required=True)
    ap.add_argument("--out_dir", default="data/processed")
    ap.add_argument("--val_frac", type=float, default=0.01)
    ap.add_argument("--no_dedup", action="store_true")
    args = ap.parse_args()

    os.makedirs(args.out_dir, exist_ok=True)
    tok = Tokenizer.from_file(args.tokenizer)
    eos_id = tok.token_to_id("<eos>")

    print("Загрузка и фильтрация...")
    docs = [d for d in iter_docs(args.input) if basic_filter(d)]
    print(f"После фильтрации: {len(docs)} документов")

    if not args.no_dedup:
        docs = dedup(docs)

    print("Токенизация...")
    all_ids = []
    for doc in tqdm(docs, desc="tokenize"):
        ids = tok.encode(doc).ids
        ids.append(eos_id)
        all_ids.extend(ids)

    arr = np.array(all_ids, dtype=np.uint16)
    n_val = int(len(arr) * args.val_frac)
    val, train = arr[:n_val], arr[n_val:]

    train.tofile(os.path.join(args.out_dir, "train.bin"))
    val.tofile(os.path.join(args.out_dir, "val.bin"))
    print(f"train: {len(train):,} токенов -> train.bin")
    print(f"val:   {len(val):,} токенов -> val.bin")


if __name__ == "__main__":
    main()
