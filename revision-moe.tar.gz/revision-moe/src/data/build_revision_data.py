"""Построение revision-traces — данных, обучающих откатам.

Каждый трейс показывает: корректный префикс -> ошибочное продолжение ->
<REVISE> -> корректное продолжение, с per-token метками confidence
(1 = корректный токен, 0 = ошибочный/будет откачен).

Здесь реализованы два генератора:
  1) from_pairs    — из пар (черновик, исправление). Самый чистый сигнал.
  2) synthetic_corrupt — портим корректный текст случайной вставкой, помечаем
     испорченный участок как low-confidence + <REVISE>. Быстрый старт без модели.

Формат выхода — JSONL, по объекту на строку:
  {"tokens": [...], "confidence_labels": [...], "revise_at": int}

Использование:
  python -m src.data.build_revision_data \
      --mode synthetic_corrupt \
      --input data/raw/clean.txt \
      --tokenizer tokenizer.json \
      --out data/revision_traces/traces.jsonl
"""
import argparse
import json
import os
import random
from tokenizers import Tokenizer
from src.model.revision import REVISE_TOKEN


def synthetic_corrupt(docs, tok, n_per_doc=1, corrupt_len=(3, 8)):
    """Берём корректный текст, в случайном месте вставляем 'мусорный' фрагмент
    (случайные токены), помечаем его confidence=0, ставим <REVISE> после него,
    далее идёт корректное продолжение (confidence=1)."""
    revise_id = tok.token_to_id(REVISE_TOKEN)
    vocab = tok.get_vocab_size()
    traces = []
    for doc in docs:
        ids = tok.encode(doc).ids
        if len(ids) < 20:
            continue
        for _ in range(n_per_doc):
            cut = random.randint(5, len(ids) - 10)
            clen = random.randint(*corrupt_len)
            garbage = [random.randint(5, vocab - 1) for _ in range(clen)]

            prefix = ids[:cut]                      # корректный префикс (conf=1)
            correct_cont = ids[cut:]                # корректное продолжение (conf=1)

            tokens = prefix + garbage + [revise_id] + correct_cont
            labels = (
                [1] * len(prefix)
                + [0] * len(garbage)                # мусор -> low confidence
                + [0]                               # сам REVISE-токен
                + [1] * len(correct_cont)
            )
            traces.append({
                "tokens": tokens,
                "confidence_labels": labels,
                "revise_at": len(prefix) + len(garbage),
            })
    return traces


def from_pairs(pairs, tok):
    """pairs: список (draft, fixed). Находим точку расхождения по токенам,
    помечаем хвост черновика как low-confidence, вставляем <REVISE> и корректный хвост."""
    revise_id = tok.token_to_id(REVISE_TOKEN)
    traces = []
    for draft, fixed in pairs:
        d = tok.encode(draft).ids
        f = tok.encode(fixed).ids
        # общий префикс
        i = 0
        while i < min(len(d), len(f)) and d[i] == f[i]:
            i += 1
        prefix = f[:i]
        bad_tail = d[i:]            # ошибочный хвост черновика
        good_tail = f[i:]           # правильный хвост
        if not bad_tail or not good_tail:
            continue
        tokens = prefix + bad_tail + [revise_id] + good_tail
        labels = [1] * len(prefix) + [0] * len(bad_tail) + [0] + [1] * len(good_tail)
        traces.append({
            "tokens": tokens,
            "confidence_labels": labels,
            "revise_at": len(prefix) + len(bad_tail),
        })
    return traces


def iter_lines(path):
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            line = line.strip()
            if line:
                yield line


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", choices=["synthetic_corrupt", "from_pairs"], required=True)
    ap.add_argument("--input", required=True,
                    help="synthetic_corrupt: txt с чистыми текстами; "
                         "from_pairs: jsonl с {'draft':..,'fixed':..}")
    ap.add_argument("--tokenizer", required=True)
    ap.add_argument("--out", default="data/revision_traces/traces.jsonl")
    ap.add_argument("--max_docs", type=int, default=100000)
    args = ap.parse_args()

    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    tok = Tokenizer.from_file(args.tokenizer)

    if args.mode == "synthetic_corrupt":
        docs = list(iter_lines(args.input))[:args.max_docs]
        traces = synthetic_corrupt(docs, tok)
    else:
        pairs = []
        for line in iter_lines(args.input):
            obj = json.loads(line)
            pairs.append((obj["draft"], obj["fixed"]))
        pairs = pairs[:args.max_docs]
        traces = from_pairs(pairs, tok)

    with open(args.out, "w", encoding="utf-8") as f:
        for t in traces:
            f.write(json.dumps(t) + "\n")
    print(f"Записано {len(traces)} трейсов -> {args.out}")


if __name__ == "__main__":
    main()
