"""Управление KV-кэшем для инференса с откатами.

При откате на позицию j нужно обрезать кэш всех слоёв до длины j по оси времени.
"""


def trim_kv_caches(kv_caches, keep_len):
    """Обрезает каждый слой кэша до keep_len токенов по временной оси (dim=2)."""
    if kv_caches is None:
        return None
    trimmed = []
    for c in kv_caches:
        if c is None or c.get("k") is None:
            trimmed.append(c)
            continue
        trimmed.append({
            "k": c["k"][:, :, :keep_len, :].contiguous(),
            "v": c["v"][:, :, :keep_len, :].contiguous(),
        })
    return trimmed


def cache_len(kv_caches):
    """Текущая длина кэша (число закэшированных токенов)."""
    if not kv_caches:
        return 0
    for c in kv_caches:
        if c is not None and c.get("k") is not None:
            return c["k"].shape[2]
    return 0
