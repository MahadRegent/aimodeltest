"""Оценка perplexity на val.bin."""
import argparse
import math
import yaml
import torch
from torch.utils.data import DataLoader

from src.model.model import RevisionMoE
from src.data.dataloader import PretrainDataset
from src.train.losses import lm_loss


@torch.no_grad()
def evaluate(model, loader, device, max_batches=200):
    model.eval()
    total, n = 0.0, 0
    for i, (x, y) in enumerate(loader):
        if i >= max_batches:
            break
        x, y = x.to(device), y.to(device)
        out = model(x)
        total += lm_loss(out["logits"], y).item()
        n += 1
    avg = total / max(n, 1)
    return avg, math.exp(avg)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--ckpt", required=True)
    ap.add_argument("--model_config", required=True)
    ap.add_argument("--train_config", required=True)
    args = ap.parse_args()

    mcfg = yaml.safe_load(open(args.model_config))["model"]
    tcfg = yaml.safe_load(open(args.train_config))["train"]
    model = RevisionMoE(mcfg).to(tcfg["device"])
    model.load_state_dict(torch.load(args.ckpt, map_location=tcfg["device"])["model"])

    ds = PretrainDataset(f"{tcfg['data_dir']}/val.bin", tcfg["seq_len"])
    loader = DataLoader(ds, batch_size=tcfg["batch_size"])
    loss, ppl = evaluate(model, loader, tcfg["device"])
    print(f"val loss {loss:.4f} | perplexity {ppl:.2f}")
