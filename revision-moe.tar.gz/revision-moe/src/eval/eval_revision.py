"""Главный замер проекта: сравнить генерацию С ревизией против БЕЗ ревизии
(той же модели) на наборе промптов. Метрика по умолчанию — средний LM-loss
сгенерированного текста под самой моделью (прокси качества/связности);
для проверяемых задач (код/математика) сюда стоит подключить pass-rate.
"""
import argparse
import math
import yaml
import torch

from tokenizers import Tokenizer
from src.model.model import RevisionMoE
from src.inference.generate import generate
from src.train.losses import lm_loss


@torch.no_grad()
def self_score(model, tok, text, device):
    """Средний NLL текста под моделью (ниже = связнее по мнению самой модели)."""
    ids = tok.encode(text).ids
    if len(ids) < 2:
        return float("nan")
    x = torch.tensor([ids[:-1]], device=device)
    y = torch.tensor([ids[1:]], device=device)
    out = model(x)
    return lm_loss(out["logits"], y).item()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ckpt", required=True)
    ap.add_argument("--model_config", required=True)
    ap.add_argument("--tokenizer", required=True)
    ap.add_argument("--prompts", required=True, help="txt: по промпту на строку")
    ap.add_argument("--device", default="cuda")
    args = ap.parse_args()

    mcfg = yaml.safe_load(open(args.model_config))["model"]
    model = RevisionMoE(mcfg).to(args.device)
    model.load_state_dict(torch.load(args.ckpt, map_location=args.device)["model"])
    tok = Tokenizer.from_file(args.tokenizer)

    prompts = [l.strip() for l in open(args.prompts) if l.strip()]
    base_scores, rev_scores = [], []

    for p in prompts:
        bt, _, _ = generate(model, tok, p, baseline=True, device=args.device)
        rt, _, _ = generate(model, tok, p, baseline=False, device=args.device)
        base_scores.append(self_score(model, tok, bt, args.device))
        rev_scores.append(self_score(model, tok, rt, args.device))

    b = sum(base_scores) / len(base_scores)
    r = sum(rev_scores) / len(rev_scores)
    print(f"baseline avg NLL: {b:.4f} (ppl {math.exp(b):.2f})")
    print(f"revision avg NLL: {r:.4f} (ppl {math.exp(r):.2f})")
    print(f"улучшение: {(b - r):.4f} NLL  ({'РЕВИЗИЯ ЛУЧШЕ' if r < b else 'нет выигрыша'})")


if __name__ == "__main__":
    main()
