import torch
from src.model.revision import find_revision_target
from src.model.model import RevisionMoE


def test_find_target_picks_min():
    conf = [1.0, 1.0, 0.9, 0.1, 0.8, 0.95]
    # минимум на позиции 3
    assert find_revision_target(conf, window=4) == 3


def test_model_forward_smoke():
    cfg = dict(
        vocab_size=128, dim=32, n_layers=4, n_heads=4, n_kv_heads=2,
        ffn_hidden=64, max_seq_len=64, rope_theta=10000.0, norm_eps=1e-5,
        moe_layers=[1, 3], n_experts=4, top_k=2, expert_hidden=64,
        use_confidence_head=True, confidence_hidden=32, use_revision=True,
    )
    model = RevisionMoE(cfg)
    x = torch.randint(0, 128, (2, 16))
    out = model(x, return_confidence=True)
    assert out["logits"].shape == (2, 16, 128)
    assert out["confidence_logit"].shape == (2, 16)
    assert out["expert_var"].shape == (2, 16)


def test_model_kv_cache_consistency():
    cfg = dict(
        vocab_size=64, dim=32, n_layers=2, n_heads=4, n_kv_heads=2,
        ffn_hidden=64, max_seq_len=32, rope_theta=10000.0, norm_eps=1e-5,
        moe_layers=[], n_experts=4, top_k=2, expert_hidden=64,
        use_confidence_head=False, confidence_hidden=32, use_revision=True,
    )
    model = RevisionMoE(cfg)
    model.eval()
    x = torch.randint(0, 64, (1, 8))
    with torch.no_grad():
        full = model(x)["logits"]
        # пошагово с кэшем
        out = model(x[:, :1])
        kv = out["new_kv_caches"]
        last = out["logits"][:, -1]
        for t in range(1, 8):
            out = model(x[:, t:t+1], kv_caches=kv, pos_offset=t)
            kv = out["new_kv_caches"]
            last = out["logits"][:, -1]
    # последний шаг должен совпасть с полным прогоном (в пределах точности)
    assert torch.allclose(last, full[:, -1], atol=1e-3)
