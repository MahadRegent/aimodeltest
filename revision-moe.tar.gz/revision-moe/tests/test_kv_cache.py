import torch
from src.inference.kv_cache import trim_kv_caches, cache_len


def make_cache(T):
    return [{"k": torch.randn(1, 2, T, 8), "v": torch.randn(1, 2, T, 8)} for _ in range(3)]


def test_trim():
    kv = make_cache(10)
    assert cache_len(kv) == 10
    kv2 = trim_kv_caches(kv, 4)
    assert cache_len(kv2) == 4
    for c in kv2:
        assert c["k"].shape[2] == 4
        assert c["v"].shape[2] == 4


def test_trim_none():
    assert trim_kv_caches(None, 5) is None
