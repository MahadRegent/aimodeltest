import torch
from src.model.moe import MoE


def test_moe_shapes_and_variance():
    moe = MoE(dim=32, hidden=64, n_experts=4, top_k=2)
    x = torch.randn(2, 5, 32)
    out, aux, var = moe(x)
    assert out.shape == (2, 5, 32)
    assert aux.dim() == 0          # скаляр
    assert var.shape == (2, 5)     # дисперсия экспертов на токен
    assert (var >= 0).all()


def test_moe_aux_loss_positive():
    moe = MoE(dim=16, hidden=32, n_experts=4, top_k=2)
    x = torch.randn(4, 8, 16)
    _, aux, _ = moe(x)
    assert aux.item() > 0
